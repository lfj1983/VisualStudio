﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RFIDDriver;
using STR2Driver;
using System.IO.Ports;

namespace STR2TestDemo
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        RFIDCardDriver<STR2Handle> m_rfid;

        public MainWindow()
        {
            InitializeComponent();
            m_rfid = new RFIDCardDriver<STR2Handle>();
            m_rfid.ReadTagEvent += new RFIDAbstract.ReadTagHandler(Rfid_ReadTagEvent);
            m_rfid.ReceivedBytesThreshold = 30;
        }

        private void btn_open_Click(object sender, RoutedEventArgs e)
        {
            m_rfid.Close();
            m_rfid.SetProperties(txt_portName.Text, Convert.ToInt32(txt_baudRate.Text), Convert.ToInt32(txt_dataBits.Text), Convert.ToInt32(txt_stopBits.Text), Convert.ToInt32(txt_parity.Text));

            m_rfid.Open();

            m_rfid.Read(0, null);
        }


        private void btn_close_Click(object sender, RoutedEventArgs e)
        {
            m_rfid.StopRead(0);
        }

        private void Rfid_ReadTagEvent(object sender, TagEventArgs e)
        {
            if (null != e)
            {
                STR2TagEventArgs args = e as STR2TagEventArgs;
                string msg = string.Format("{0},{1},{2},{3},{4}\n", args.Tag, args.Attribute, args.Sequenced, args.Count, args.Model);
                this.Dispatcher.Invoke(new ShowMsgDelegate(ShowMsg), new object[] { msg });

            }
        }
        delegate void ShowMsgDelegate(string msg);
        private void ShowMsg(string msg)
        {
            textBox1.AppendText(msg);
            textBox1.ScrollToEnd();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            m_rfid.StopRead(0);
            m_rfid.Close();
        }


    }
}
